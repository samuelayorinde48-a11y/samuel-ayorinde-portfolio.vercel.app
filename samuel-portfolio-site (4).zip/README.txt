Upload every file in this folder to GitHub, all at the top level. No folders needed.

Files: index.html, favicon.svg, portrait.webp, eloria.webp, verno.webp, vantera.webp, aurelis.webp
portrait.webp is used in the hero and in the About section.
